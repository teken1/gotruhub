import React from "react";
import { DashboardContent, MainLayout } from "../../components";

export const Dashbaord = () => {
  return (
    <MainLayout>
      <DashboardContent />
    </MainLayout>
  );
};
