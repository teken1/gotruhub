import React from "react";
import { NewProduct } from "../../components";
import { MainLayout } from "../../components";

export const NewService = () => {
  return (
    <MainLayout>
      <NewProduct />
    </MainLayout>
  );
};
