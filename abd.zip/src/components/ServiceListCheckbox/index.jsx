import React from "react";

export const ServiceListCheckbox = () => {
  return (
    // <section className="productholder">
    //   <div className="sellproduct">
    //     <div className="addservice">
    //       <h3>Add New Product/Service</h3>
    //     </div>
    //     <div className="greenproducts">
    //       <button>Products</button>
    //       <button>Service</button>
    //     </div>

    //     <div className="namedproduct">
    //       <div className="productinput">
    //         <label>Product name</label>
    //         <input type="text" placeholder="Product name" />
    //       </div>

    //       <div className="productinput">
    //         <label>Category</label>
    //         <select className="categorize">
    //           <option>Select Category</option>
    //         </select>
    //       </div>

    //       <div className="productinput">
    //         <label>Manufacturer</label>
    //         <input type="text" placeholder="Enter Manufacturer" />
    //       </div>

    //       <div className="productinputType">
    //         <div className="productinputText">
    //           <label>Cost Price</label>
    //           <input type="text" placeholder="0.00" />
    //         </div>

    //         <div className="productinputText">
    //           <label>Selling Price</label>
    //           <input type="text" placeholder="0.00" />
    //         </div>
    //       </div>

    //       <div className="productinputType">
    //         <div className="productinputText">
    //           <label>Available Quantity (optional)</label>
    //           <input type="text" placeholder="0" />
    //         </div>

    <div className="productinputText">
      <label>Is this subscription based?</label>
      <div className="radiobox">
        <div className="radio">
          <input type="radio" />
          <label>Yes</label>
        </div>
        <div className="radio">
          <input type="radio" />
          <label>No</label>
        </div>
      </div>
    </div>
    //       </div>

    //       <div className="productinputType">
    //         <div className="productinputText">
    //           <label>Select Duration (optional)</label>
    //           <select className="categorizeText">
    //             <option>Days(s)</option>
    //           </select>
    //         </div>

    //         <div className="productinputText">
    //           <label>Minimum Quantity</label>
    //           <select className="categorizeText">
    //             <option>0</option>
    //           </select>
    //         </div>
    //       </div>
    //     </div>

    //     <div className="includebton">
    //       <button>Add Product</button>
    //     </div>
    //   </div>
    // </section>
  );
};
